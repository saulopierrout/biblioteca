"""Flash Crop em código: junta clipes e, nos últimos quadros antes de cada corte,
põe por cima um recorte do próximo clipe com flash, tremida, inclinação e desfoque de movimento.

Mesma receita do Premiere:
  - o próximo clipe entra N quadros antes do corte, numa camada acima (padrão: 3);
  - Cortar: só um retângulo aparece (muda a cada corte);
  - Níveis: entrada de branco começa em 140 (estourado) e volta a 255 no fim;
  - Posição e escala: ajuste mínimo nos 2 primeiros quadros (tremida);
  - Transformar: inclinação de 0 a 20 graus, obturador acima de 300 (desfoque de movimento).

Uso:
  python flash_crop.py clip1.mp4 clip2.mp4 clip3.mp4 ... -o saida.mp4
  opções: --quadros 3  --flash 140  --inclinacao 20  --duracao 0.6 (segundos de cada clipe; 0 = clipe inteiro)
          --largura 1080 --altura 1920 --fps 30 --semente 7
Requer: Python 3, numpy, Pillow e PyAV (pip install numpy pillow av).
"""
import argparse, math, random
import numpy as np
from PIL import Image
import av


def ler_quadros(caminho, W, H, fps, duracao):
    c = av.open(caminho); s = c.streams.video[0]
    quadros, t0 = [], None
    passo = 1.0 / fps
    proximo = 0.0
    for f in c.decode(s):
        t = float(f.pts * s.time_base) if f.pts is not None else proximo
        if t0 is None: t0 = t
        t -= t0
        if duracao and t >= duracao: break
        if t + 1e-6 < proximo: continue           # reamostra para o fps de saída
        img = f.to_image().convert("RGB")
        # preenche a tela (cover), como um clipe esticado na timeline
        esc = max(W / img.width, H / img.height)
        img = img.resize((math.ceil(img.width * esc), math.ceil(img.height * esc)), Image.LANCZOS)
        x, y = (img.width - W) // 2, (img.height - H) // 2
        quadros.append(np.asarray(img.crop((x, y, x + W, y + H)), np.float32))
        proximo += passo
    c.close()
    return quadros


def camada_flash(fonte, W, H, ret, p, k, args, rnd_mov):
    """Monta um quadro da camada de cima (RGBA) para o progresso p (0 a 1)."""
    x0, y0, x1, y1 = ret
    branco = args.flash + (255 - args.flash) * p          # Níveis: 140 -> 255
    img = np.clip(fonte * (255.0 / branco), 0, 255)
    alfa = np.zeros((H, W), np.float32); alfa[y0:y1, x0:x1] = 255  # Cortar
    rgba = Image.fromarray(np.dstack([img, alfa]).astype(np.uint8), "RGBA")
    # tremida: nos 2 primeiros quadros a posição e a escala mudam um pouco
    t = min(k, 2) / 2.0
    dx, dy, ds = rnd_mov
    escala = 1.0 + ds * t
    desloca = (dx * t * W, dy * t * H)
    # desfoque de movimento (obturador > 300): média de sub-quadros entre a pose anterior e esta
    passo_p = 1.0 / max(1, args.quadros - 1)
    soma = np.zeros((H, W, 4), np.float32)
    subs = 5
    for j in range(subs):
        pp = max(0.0, p - passo_p * 0.85 * (1 - j / (subs - 1)))
        inc = math.tan(math.radians(args.inclinacao * pp))   # inclinação 0 -> 20
        cx, cy = W / 2, H / 2
        # matriz inversa (PIL pede saída -> entrada): escala em volta do centro + cisalhamento horizontal + deslocamento
        a, b, c = 1 / escala, -inc / escala, cx - (cx + desloca[0]) / escala + inc * (cy + desloca[1]) / escala
        d, e, f = 0, 1 / escala, cy - (cy + desloca[1]) / escala
        soma += np.asarray(rgba.transform((W, H), Image.AFFINE, (a, b, c, d, e, f), Image.BILINEAR), np.float32)
    return soma / subs


def main():
    ap = argparse.ArgumentParser(description="Flash Crop: transição de recorte com flash entre clipes")
    ap.add_argument("clipes", nargs="+")
    ap.add_argument("-o", "--saida", default="flash-crop.mp4")
    ap.add_argument("--quadros", type=int, default=3)
    ap.add_argument("--flash", type=float, default=140)
    ap.add_argument("--inclinacao", type=float, default=20)
    ap.add_argument("--duracao", type=float, default=0)
    ap.add_argument("--largura", type=int, default=1080)
    ap.add_argument("--altura", type=int, default=1920)
    ap.add_argument("--fps", type=float, default=30)
    ap.add_argument("--semente", type=int, default=7)
    args = ap.parse_args()
    W, H, N = args.largura, args.altura, args.quadros
    rnd = random.Random(args.semente)
    clipes = [ler_quadros(c, W, H, args.fps, args.duracao) for c in args.clipes]

    out = av.open(args.saida, "w")
    st = out.add_stream("libx264", rate=round(args.fps))
    st.width, st.height, st.pix_fmt = W, H, "yuv420p"
    st.options = {"crf": "18", "preset": "medium"}
    for i, qs in enumerate(clipes):
        prox = clipes[i + 1] if i + 1 < len(clipes) else None
        if prox:
            # recorte novo a cada corte: retângulo alto (45% a 80% da altura, 40% a 70% da largura),
            # muitas vezes encostado numa borda, como no Premiere
            w = int(W * rnd.uniform(0.40, 0.70)); h = int(H * rnd.uniform(0.45, 0.80))
            x0 = rnd.choice([0, W - w, rnd.randint(0, W - w)]); y0 = rnd.choice([0, H - h, rnd.randint(0, H - h)])
            ret = (x0, y0, x0 + w, y0 + h)
            mov = (rnd.uniform(-0.015, 0.015), rnd.uniform(-0.015, 0.015), rnd.uniform(0.02, 0.05))
        for n, base in enumerate(qs):
            k = n - (len(qs) - N)                     # k >= 0: dentro dos últimos N quadros
            if prox and k >= 0:
                p = k / max(1, N - 1)
                cam = camada_flash(prox[min(k, len(prox) - 1)], W, H, ret, p, k, args, mov)
                a = cam[..., 3:4] / 255.0
                quadro = base * (1 - a) + cam[..., :3] * a
            else:
                quadro = base
            fr = av.VideoFrame.from_ndarray(np.clip(quadro, 0, 255).astype(np.uint8), format="rgb24")
            for pkt in st.encode(fr): out.mux(pkt)
    for pkt in st.encode(): out.mux(pkt)
    out.close()
    print("ok:", args.saida)


if __name__ == "__main__":
    main()
